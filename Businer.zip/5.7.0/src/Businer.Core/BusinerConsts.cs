﻿namespace Businer
{
    public class BusinerConsts
    {
        public const string LocalizationSourceName = "Businer";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
